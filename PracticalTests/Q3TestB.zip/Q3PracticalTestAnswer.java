
public class Q3PracticalTestAnswer
{
    // global variables and constants, do not modify-------+
    public final static int MAXSIZE = 10;  //              |
    public static int population = 0;      //              |
    public static String[] array = new String[MAXSIZE]; // |
    // ----------------------------------------------------+

    public static boolean isFull()
    {
		return population == MAXSIZE;
    }

    public static boolean isEmpty()
    {
		return population == 0;
    }

    public static void printWholeArray()
    {
		for (int i = 0; i < array.length; i++)
        {	System.out.print(i + ":" + array[i] + "  ");
        }
        System.out.printf("[ length: %d ]\n", array.length);
    }


    public static void printArray()
    {
        for (int i = 0; i < MAXSIZE; i++)
        {
            if (array[i] != null)
            {	System.out.print(i + ":" + array[i] + "  ");
			}
        }
        System.out.printf("[ population: %d ]\n", population);
    }
    
    public static String[] clone(String[] originalArray)
    {	String[] b = new String[originalArray.length];
        for (int i = 0; i < originalArray.length; i++)
        {	b[i] = originalArray[i];
        }
        return b;
    }
    
    public static void add(String data)
    {
        if ( isFull() )
        {    System.out.println("Error adding " + data);
        } else
        {	for (int i = 0; i < MAXSIZE; i++)
            {	if (array[i] == null)
                {	array[i] = data;
                    population++;
                    //printArray(array); // optional
                    return;
                }
            }
        }
    }

    public static int search(String data)
    {
        for (int i = 0; i < MAXSIZE; i++)
        {
            if (array[i] != null)
            {	if (array[i].equalsIgnoreCase(data))
                {	return i;
				}
			}
        }
        return -1;
    }
    
    public static void swap(int index1, int index2)
    {	if ((index1 < 0 || index1 >= MAXSIZE) || (index2 < 0 || index2 >= MAXSIZE))
        {
            System.out.println("Error in index value(s)");
            return;
        } else
        {
            String temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }
    }

    public static void replace(String original, String replacement)
    {
        int indexToReplace = search(original);
        if (indexToReplace == -1)
        {	System.out.printf("%s not found.\n", original);
        } else
        {	array[indexToReplace] = replacement;
        }
    }

    public static void replaceAll(String original, String replacement)
    {
        int indexToReplace = search(original);
        if (indexToReplace == -1)
        {	System.out.printf("%s not found.\n", original);
        } else
        {
            while (indexToReplace != -1)
            {	array[indexToReplace] = replacement;
                indexToReplace = search(original);
            }
        }
    }

    public static void remove(String data)
    {
        int indexToRemove = search(data);
        if (indexToRemove == -1)
        {
            System.out.printf("%s not found.\n", data);
        } else
        {
            array[indexToRemove] = null;
            population--;
        }
    }

    // optional
    public static void remove(int indexToRemove)
    {
        if (indexToRemove < 0 || indexToRemove >= MAXSIZE)
        {	if (indexToRemove == -1)
            {
                System.out.printf("Index %d not found.\n", indexToRemove);
            } else
            {
                array[indexToRemove] = null;
                population--;
            }
		}
    }

    public static void insert(String data, int index)
    {
		if ((index < 0 || index >= MAXSIZE))
        {	System.out.println("Error in index value(s)");
            return;
		}
        if (isFull() == true)
        {	System.out.println("Error - array full");
            return;
		}
		String temp = array[index];
		array[index] = data;
		add(temp);
    }


	// Do not modify the code below this line--------------------------------------------------------------------------
    public static void main(String[] args)
    {
        System.out.println("1. printWholeArray + length:\n   Expected output >>> 0:null  1:null  2:null  3:null  4:null  5:null  6:null  7:null  8:null  9:null  [ length: 10 ]");
        System.out.print("   Y O U R  output >>> "); printWholeArray();
        System.out.println("\n2. printArray + population:\n   Expected output >>> [ population: 0 ]");
        System.out.print("   Y O U R  output >>> "); printArray();
        System.out.println("\n3. Testing isFull()  method [false] >>> " + isFull());
        System.out.println("   Testing isEmpty() method [true]  >>> " + isEmpty());
        System.out.println("\n4. Testing the add() method...");
        add("apple");
        add("banana");
        add("cherry");
        add("dragonfruit");
        add("elderberry");
        add("fig");
        add("gooseberry");
        add("imbe");
        add("jujube");
        add("kiwi");
        System.out.print("   Output should be: Error adding longan >>> ");
        add("longan");
        System.out.println("   Expected output >>> 0:apple  1:banana  2:cherry  3:dragonfruit  4:elderberry  5:fig  6:gooseberry  7:imbe  8:jujube  9:kiwi  [ population: 10 ]");
        System.out.print("   Y O U R  output >>> ");
        printArray();
        System.out.println("\n5. Test search(\"banana\") method [1]: " + search("banana"));
        System.out.println("   Test search(\"grape\") method [-1]: " + search("grape"));
        String[] full = clone(array);
        System.out.println("\n6. Testing clone method String[] full = clone(); [false]: " + array.equals(full));
        System.out.println("\n7. Testing remove(\"dragonfruit\"); remove(\"gooseberry\"); - output should be as below:");
        remove("dragonfruit");
        remove("gooseberry");
        System.out.print("   Testing remove(\"watermelon\") should output error: watermelon not found >>> ");
        remove("watermelon");  
        System.out.println("8. Testing swap(0, 5);");
		swap(0, 5);
        System.out.println("   Testing swap(3, 10); swap(-3, 1); this should generate two errors >>>");
        System.out.print("   "); swap(3, 10);
        System.out.print("   "); swap(-3, 1);
        System.out.println("   Expected output >>> 0:fig  1:banana  2:cherry  4:elderberry  5:apple  7:imbe  8:jujube  9:kiwi  [ population: 8 ] (printArray)");
        System.out.print("   Y O U R  output >>> "); printArray();
        System.out.println("\n9. Testing replace(\"apple\", \"papaya\") ");
        replace("apple", "papaya");
        System.out.println("   Expected output >>> 0:fig  1:banana  2:cherry  3:null  4:elderberry  5:papaya  6:null  7:imbe  8:jujube  9:kiwi  [ length: 10 ] (printWholeArray)");
        System.out.print("   Y O U R  output >>> ");
        printWholeArray();
        System.out.print("   Testing replace(\"watermelon\", \"apple\") should output error: watermelon not found >>> ");
        replace("watermelon", "apple");
        System.out.println("\n10. Testing insert(\"plum\", 0) ");
        insert("plum", 0);
        System.out.println("    Expected output >>> 0:plum  1:banana  2:cherry  3:fig  4:elderberry  5:papaya  6:null  7:imbe  8:jujube  9:kiwi  [ length: 10 ] (printWholeArray)");
        System.out.print("    Y O U R  output >>> ");
        printWholeArray();
        System.out.print("    Testing insert(\"mango\", 11) should output an error >>> ");
        insert("mango", 11);
        
    }
}

