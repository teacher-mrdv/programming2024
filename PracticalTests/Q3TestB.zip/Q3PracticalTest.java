
public class Q3PracticalTest
{
    // global variables and constants, do not modify-------+
    public final static int MAXSIZE = 10;  //              |
    public static int population = 0;      //              |
    public static String[] array = new String[MAXSIZE]; // |
    // ----------------------------------------------------+

    public static boolean isFull()
    {
		// your code! (remember to change the line below as well!)
        return false;
    }

    public static boolean isEmpty()
    {
		// your code! (remember to change the line below as well!)
        return false;
    }

    public static void printArray()
    {
        // your code!
    }

    public static void printWholeArray()
    {
		// your code!
    }

    public static String[] clone(String[] originalArray)
    {
        // your code! (remember to change the line below as well!)
        return null;
    }

    public static void add(String data)
    {
        // your code!
    }

    public static int search(String data)
    {
        // your code! (remember to change the line below as well!)
        return 0;
    }

    public static void swap(int index1, int index2)
    {
		// your code!
    }

    public static void replace(String original, String replacement)
    {
        // your code!
    }

    public static void remove(String data)
    {
		// your code!
    }

    public static void insert(String data, int index)
    {
		// your code!
    }

	// Do not modify the code below this line--------------------------------------------------------------------------
    public static void main(String[] args)
    {
        System.out.println("1. printWholeArray + length:\n   Expected output >>> 0:null  1:null  2:null  3:null  4:null  5:null  6:null  7:null  8:null  9:null  [ length: 10 ]");
        System.out.print("   Y O U R  output >>> "); printWholeArray();
        System.out.println("\n2. printArray + population:\n   Expected output >>> [ population: 0 ]");
        System.out.print("   Y O U R  output >>> "); printArray();
        System.out.println("\n3. Testing isFull()  method [false] >>> " + isFull());
        System.out.println("   Testing isEmpty() method [true]  >>> " + isEmpty());
        System.out.println("\n4. Testing the add() method...");
        add("apple");
        add("banana");
        add("cherry");
        add("dragonfruit");
        add("elderberry");
        add("fig");
        add("gooseberry");
        add("imbe");
        add("jujube");
        add("kiwi");
        System.out.print("   Output should be: Error adding longan >>> ");
        add("longan");
        System.out.println("   Expected output >>> 0:apple  1:banana  2:cherry  3:dragonfruit  4:elderberry  5:fig  6:gooseberry  7:imbe  8:jujube  9:kiwi  [ population: 10 ]");
        System.out.print("   Y O U R  output >>> ");
        printArray();
        System.out.println("\n5. Test search(\"banana\") method [1]: " + search("banana"));
        System.out.println("   Test search(\"grape\") method [-1]: " + search("grape"));
        String[] full = clone(array);
        System.out.println("\n6. Testing clone method String[] full = clone(); [false]: " + array.equals(full));
        System.out.println("\n7. Testing remove(\"dragonfruit\"); remove(\"gooseberry\"); - output should be as below:");
        remove("dragonfruit");
        remove("gooseberry");
        System.out.print("   Testing remove(\"watermelon\") should output error: watermelon not found >>> ");
        remove("watermelon");  
        System.out.println("8. Testing swap(0, 5);");
		swap(0, 5);
        System.out.println("   Testing swap(3, 10); swap(-3, 1); this should generate two errors >>>");
        System.out.print("   "); swap(3, 10);
        System.out.print("   "); swap(-3, 1);
        System.out.println("   Expected output >>> 0:fig  1:banana  2:cherry  4:elderberry  5:apple  7:imbe  8:jujube  9:kiwi  [ population: 8 ] (printArray)");
        System.out.print("   Y O U R  output >>> "); printArray();
        System.out.println("\n9. Testing replace(\"apple\", \"papaya\") ");
        replace("apple", "papaya");
        System.out.println("   Expected output >>> 0:fig  1:banana  2:cherry  3:null  4:elderberry  5:papaya  6:null  7:imbe  8:jujube  9:kiwi  [ length: 10 ] (printWholeArray)");
        System.out.print("   Y O U R  output >>> ");
        printWholeArray();
        System.out.print("   Testing replace(\"watermelon\", \"apple\") should output error: watermelon not found >>> ");
        replace("watermelon", "apple");
        System.out.println("\n10. Testing insert(\"plum\", 0) ");
        insert("plum", 0);
        System.out.println("    Expected output >>> 0:plum  1:banana  2:cherry  3:fig  4:elderberry  5:papaya  6:null  7:imbe  8:jujube  9:kiwi  [ length: 10 ] (printWholeArray)");
        System.out.print("    Y O U R  output >>> ");
        printWholeArray();
        System.out.print("    Testing insert(\"mango\", 11) should output an error >>> ");
        insert("mango", 11);
        
    }
}

