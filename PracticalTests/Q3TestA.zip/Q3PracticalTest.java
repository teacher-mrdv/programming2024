
public class Q3PracticalTest
{
    // global variables and constants
    public final static int MAXSIZE = 10;
    public static int population = 0;
    public static String[] array = new String[MAXSIZE];

    public static boolean isFull()
    {
        // your code goes here
        return false; // modify!
    }

    public static boolean isEmpty()
    {
        // your code goes here
        return false; // modify!
    }

    public static void printWholeArray()
    {
        // your code goes here
    }
    
    public static void printArray()
    {
		// your code goes here
    }
    
    public static void printReversedArray()
    {
		// your code goes here
    }
    
    public static int free()
    {	int counter = 0;
		// your code goes here
		return counter;
	}

    public static void add(String data)
    {
		// your code goes here
    }

    public static int search(String data)
    {
		// your code goes here
        return -1;
    }
    
    public static String remove()
    {
		// your code goes here
		return "";
	}

    public static void main(String[] args)
    {
        System.out.println("printWholeArray() + length:\n   Expected output >>> 0:null  1:null  2:null  3:null  4:null  5:null  6:null  7:null  8:null  9:null  [ length: 10 ]");
        System.out.print("   Y O U R  output >>> "); printWholeArray();
        System.out.println("\nprintArray + population:\n   Expected output >>> [ population: 0 ]");
        System.out.print("   Y O U R  output >>> "); printArray();
        System.out.println("\nisFull()  method [false] >>> " + isFull());
        System.out.println("isEmpty() method [true]  >>> " + isEmpty());
        System.out.println("\nadd() method...");
		add("kiwi");
		add("jujube");
		add("imbe");
		add("gooseberry");
		add("fig");
		add("elderberry");
		add("dragonfruit");
		add("cherry");
		add("banana");
		add("apple");
        System.out.println("   Expected output >>> 0:apple  1:banana  2:cherry  3:dragonfruit  4:elderberry  5:fig  6:gooseberry  7:imbe  8:jujube  9:kiwi  [ population: 10 ]");
        System.out.print("   Y O U R  output >>> ");
        printArray();
        System.out.println("\nprintReversedArray() method:");
        System.out.println("   Expected output >>> 9:kiwi  8:jujube  7:imbe  6:gooseberry  5:fig  4:elderberry  3:dragonfruit  2:cherry  1:banana  0:apple  [ population: 10 ]");
        System.out.print("   Y O U R  output >>> ");
        printReversedArray();
        System.out.println("\nsearch(\"kiwi\")  method [9]: " + search("kiwi"));
        System.out.println("search(\"grape\") method [-1]: " + search("grape"));
        System.out.print("\nadd(\"fig\")   method (no duplicates): "); add("fig");
        System.out.print("add(\"apple\") method (no duplicates): "); add("apple");
        System.out.print("add(\"kiwi\")  method (no duplicates): "); add("kiwi");
        System.out.println("   Expected output >>> 0:apple  1:banana  2:cherry  3:dragonfruit  4:elderberry  5:fig  6:gooseberry  7:imbe  8:jujube  9:kiwi  [ population: 10 ]");
        System.out.print("   Y O U R  output >>> ");
        printArray();
        System.out.println("\nadd(\"longan\") method (overflow when array full)"); add("longan");
        System.out.println("add(\"plum\")   method (overflow when array full)"); add("plum");
        System.out.println("   Expected output >>> 0:plum  1:longan  2:apple  3:banana  4:cherry  5:dragonfruit  6:elderberry  7:fig  8:gooseberry  9:imbe  [ population: 10 ]");
        System.out.print("   Y O U R  output >>> ");
        printArray();
        System.out.println("\nremove() and free() methods:");
        remove();
        System.out.println("   remove(); free() [1]: " + free() );
        remove();
        System.out.println("   remove(); free() [2]: " + free() );
        System.out.println("   Expected output >>> 2:apple  3:banana  4:cherry  5:dragonfruit  6:elderberry  7:fig  8:gooseberry  9:imbe  [ population: 8 ]");
        System.out.print("   Y O U R  output >>> ");
        printArray();
        
       
    }
}

